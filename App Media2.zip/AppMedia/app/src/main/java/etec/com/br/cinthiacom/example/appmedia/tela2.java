package etec.com.br.cinthiacom.example.appmedia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class tela2 extends AppCompatActivity {

    Float valorRecebido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        Intent telaAtual= getIntent();
        Bundle valor = telaAtual.getExtras();

        valorRecebido =


        if ()

    }
}