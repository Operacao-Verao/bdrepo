package etec.com.br.cinthiacom.example.appmedia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btCalcular;
    EditText edPrimeiranota, edSegundanota, edTerceiraNota;
    float resultado, nota1, nota2, nota3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btCalcular = findViewById(R.id.btnCalcular);
        edPrimeiranota = findViewById(R.id.edtPrimeiranota);
        edSegundanota = findViewById(R.id.edtSegundaNota);
        edTerceiraNota = findViewById(R.id.edtTerceiraNota);


        btCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (edPrimeiranota.getText().toString().isEmpty()){
                    edPrimeiranota.setError("Campo Obrigatório");
                    edPrimeiranota.requestFocus();
                }
                else if (edSegundanota.getText().toString().isEmpty()){
                    edSegundanota.setError("Campo Obrigatório");
                    edSegundanota.requestFocus();
                } else if (edTerceiraNota.getText().toString().isEmpty()) {
                    edTerceiraNota.setError("Campo Obrigatório");
                    edTerceiraNota.requestFocus();

                }
                else {
                    nota1 = Float.parseFloat(edPrimeiranota.getText().toString());
                    nota2 = Float.parseFloat(edSegundanota.getText().toString());
                    nota3 = Float.parseFloat(edTerceiraNota.getText().toString());

                    resultado = (nota1 + nota2 + nota3) / 3;

                    Toast.makeText(MainActivity.this, "A média é " + resultado, Toast.LENGTH_SHORT).show();
                    Intent tela2 = new Intent(MainActivity.this, tela2.class);
                    tela2.putExtra("resultado", resultado;

                }

            }



        });


    }
}